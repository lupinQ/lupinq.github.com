/* calc_a_s.c */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include <time.h>
#define PI 3.1415926535898

/* add */
double calc_add(double a1, double a2)
{
    double result = 0;
    
    result = a1 + a2;
    
    return result;
}

/* sub */
double calc_sub(double s1, double s2)
{
    double result = 0;
    
    result = s1 - s2;
    
    return result;
}
/*multip*/
double calc_multip( double a1, double a2)
{
    double result = 0;
    
    result = a1 * a2;
    
    return result;
}

/*divise*/
double calc_divise( double a1, double a2)
{
   double result = 0;
    
    result = a1 / a2;
    
    return result;
}

/*PI*/
const double calc_PI()
{   
    return PI;
}

/*sin*/
double calc_sin( double a1)
{
    double result = 0;
    
    result = sin(a1/180*PI);
    
    return result;
}

/*cos*/
double calc_cos( double a1)
{
    double result = 0;
    
    result = cos(a1/180*PI) ;
    
    return result;
}

/*tan*/
double calc_tan( double a1)
{
    double result = 0;
    
    result = tan(a1/180*PI);
    
    return result;
}

/*abs*/
double calc_abs( double a1)
{
    double result = 0;
    
    result = fabs(a1);
    
    return result;
}

/*exp*/
double calc_exp( double a1)
{
    double result = 0;
    
    result = exp(a1);
    
    return result;
}

/*log*/
double calc_log( double a1)
{
    double result = 0;
    
    result = log(a1);
    
    return result;
    
}

/*log10*/
double calc_log10( double a1)
{
    double result = 0;
    
    result = log10(a1);
    
    return result;
}

/*pow*/
double calc_pow( double a1, double a2)
{
    double result = 0;
    
    result = pow(a1,a2);
    
    return result;
}

/*rand*/
int calc_rand()
{
    double result = 0;
    
    srand((unsigned)time(NULL));
    result=rand()%100;
    return result;
}
/*error*/
int calc_err(const int n){
    switch(n){
    case 1:printf("the mod must be digit!\n");break;
    case 2:printf("the data must be digit!\n");break;
    case 3:printf("the dividend can't be zero!\n");break;
    case 4:printf("the data must be more than zero!\n");break;
    }
    return 0;

}
/* main */
int main (int argc, const char** argv)    // Have Problems! Do you know why?
{
	unsigned int calc_mod = 0;
	double idata  = 0;
    double kdata  = 0;
    double result = 0;
    
    printf(" 1.add\n 2.sub\n 3.multip\n 4.divise\n 5.PI\n 6.sin\n 7.cos\n 8.tan\n 9.abs\n10.exp\n11.log\n12.log10\n13.pow\n14.rand\n");
    switch(argc){
    case 1: printf("enter cmd numbers must >= 2!!!\n");return 0;

    case 2: argv ++;
            if(**argv<='9' && **argv>='0')
            if((calc_mod = atoi(*argv))==5 || calc_mod >=14) { 
            printf("Enter is mod<%d>\n", calc_mod);
            break;        
            }
            else {printf("in %d mode ,enter cmd numbers must > 2!!!\n",calc_mod);return 0;}
            else {
            calc_err(1);
            return 0;}
    case 3: 
    argv ++;    
    if(**argv<='9' && **argv>='0'){
    calc_mod = atoi(*argv);
    argv ++;
    idata = atof(*argv);
    if((**argv<='9' && **argv>='0')||( **argv=='-' && (*(*argv+1)<='9' && *(*argv+1)>='0'))){
    if(calc_mod >4 || calc_mod!=13){ 
    printf("Enter is mod<%d> data_f<%g> \n", calc_mod, idata);
    break;
    }
    else { printf("in %d mode ,enter cmd numbers must > 3!!!\n",calc_mod);return 0;}}
    else {calc_err(1);return 0;}
    }
    else {calc_err(2);return 0;} 
    case 4:
    argv ++;
    if(**argv<='9' && **argv>='0'){
    calc_mod = atoi(*argv);
    argv ++;    
    if((**argv<='9' && **argv>='0')||( **argv=='-' && (*(*argv+1)<='9' && *(*argv+1)>='0'))){
    idata = atof(*argv);
    argv ++;    
    if((**argv<='9' && **argv>='0')||( **argv=='-' && (*(*argv+1)<='9' && *(*argv+1)>='0'))){
    kdata = atof(*argv);
    printf("Enter is mod<%d> data_f<%g> data_b<%g> \n", calc_mod, idata, kdata);
    break; }
    else {calc_err(2);return 0;}}
    else {calc_err(2);return 0;}}
    else {calc_err(1);return 0;}
    default :
    printf("enter cmd numbers must < 5!!!\n");
    return 0;
    }
    switch(calc_mod)
    {
    	    case 1:
    	    	    result = calc_add(idata, kdata);   
                printf("Calc add (%g + %g) result is %g\n", idata, kdata, result);  	    	
    	    	break;
    	    	
    	    case 2:
    	    	    result = calc_sub(idata, kdata);
                printf("Calc sub (%g - %g) result is %g\n", idata, kdata, result);     	    	    
    	    	break;
    	      case 3:
    	    	    result = calc_multip(idata, kdata);
                printf("Calc multip (%g * %g) result is %g\n", idata, kdata, result);     	    	    
    	    	break;
    	   	  case 4:
    	    	
                if(kdata!=0){
                result = calc_divise(idata, kdata);
                printf("Calc divise (%g / %g) result is %g\n", idata, kdata, result);     	    	    
    	    	break;}
                else {calc_err(3);return 0;}
    	     case 5:
    	    	    result = calc_PI();
                printf("Calc PI result is %g\n",(const double)result);     	    	    
    	    	break;
    	     case 6:
    	    	    result = calc_sin(idata);
                printf("Calc sin (%g) result is %g\n", idata, result);     	    	    
    	   	break;
    	     case 7:
    	    	    result = calc_cos(idata);
                printf("Calc cos (%g) result is %g\n", idata, result);     	    	    
    	    	break;
    	    case 8:
    	    	    result = calc_tan(idata);
                printf("Calc tan (%g) result is %g\n", idata, result);     	    	    
    	    	break;
    	    case 9:
    	    	    result = calc_abs(idata);
                printf("Calc abs (%g) result is %g\n", idata, result);     	    	    
    	    	break;
    	    case 10:
    	    	    result = calc_exp(idata);
                printf("Calc exp (%g) result is %g\n", idata, result);     	    	    
    	    	break;
    	    case 11:
    	        	    
                if(idata>0){
                result = calc_log(idata);
                printf("Calc log (%g) result is %g\n", idata, result);     	    	    
    	    	break;}
                else {calc_err(4);return 0;}
    	    case 12:
    	    	   
                if(idata>0){
                result = calc_log10(idata);
                printf("Calc log10 (%g) result is %g\n", idata, result);     	    	    
    	    	break;}
                else {calc_err(4);return 0;}
    	    case 13:
    	    	    result = calc_pow(idata, kdata);
                printf("Calc pow (%g , %g) result is %g\n", idata, kdata, result);     	    	    
    	    	break;
    	    case 14:
    	    	   result = (double)calc_rand();
                printf("Calc rand () result the result is %d\n",(int)result);     	    	    
    	    	break;
    	   
    	    default:
    	    	    printf("Enter calc mod error!!!\n");
    	    	break;
    }
    
    return 0;
}

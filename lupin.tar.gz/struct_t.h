/* struct_t.h */

 struct space_3d
{
     int x;
     float y;
     double z;
     char * name;
};

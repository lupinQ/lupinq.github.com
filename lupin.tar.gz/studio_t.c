/* studio */

#include <stdio.h>
#include "struct_t.h"
#include <stdlib.h>
int main( int argc, char ** argv)
{
   //  struct space_3d cs,*sp=&cs;
   struct space_3d *sp=(struct space_3d *)malloc(sizeof(struct space_3d));
     char sp_name[] = "gps";
     
    // cs.x = 255;
    // cs.y = 512;
    // cs.z = 1024;
    // cs.name = sp_name;
      sp->x = 255;
      sp->y = 512;
      sp->z = 1024;
      sp->name = sp_name;
    
    printf(" sp->x (value is %d)\n sp->y (value is %f) \n", sp->x, sp->y);
     printf(" sp->z (value is %f)\n sp->name (name is %s)\n", sp->z, (char*)(sp->name));
//     printf(" cs.x (value is %d)\n cs.y (value is %f) \n", cs.x, cs.y);
//     printf(" cs.z (value is %f)\n cs.name (name is %s)\n", cs.z, (char*)(cs.name));
     
     return 0;
}
